"""Speech in, speech out."""
import speech_recognition as sr
import pyttsx3
import config

_engine = pyttsx3.init()
_engine.setProperty("rate", config.VOICE_RATE)

# Try to pick a deeper/male-sounding installed voice for the Ultron tone.
for v in _engine.getProperty("voices"):
    if "male" in v.name.lower() or "david" in v.name.lower() or "mark" in v.name.lower():
        _engine.setProperty("voice", v.id)
        break

_recognizer = sr.Recognizer()


def speak(text: str):
    print(f"ULTRON: {text}")
    _engine.say(text)
    _engine.runAndWait()


def listen(timeout=5, phrase_time_limit=8):
    """Listens from the default microphone and returns lowercase transcript, or '' on failure."""
    with sr.Microphone() as source:
        _recognizer.adjust_for_ambient_noise(source, duration=0.4)
        try:
            audio = _recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
        except sr.WaitTimeoutError:
            return ""
    try:
        text = _recognizer.recognize_google(audio)
        print(f"YOU: {text}")
        return text.lower()
    except (sr.UnknownValueError, sr.RequestError):
        return ""


def confirm(prompt="Are you sure? Say yes or no."):
    """Spoken confirmation gate for destructive actions."""
    speak(prompt)
    answer = listen(timeout=6, phrase_time_limit=4)
    return answer.strip().startswith("yes")
