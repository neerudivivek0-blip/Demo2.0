"""Every action Ultron takes gets appended here - useful for reviewing what
happened, especially for destructive or messaging actions."""
import datetime
import os

LOG_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ultron_action_log.txt")

def log_action(action, detail="", result="ok"):
    line = f"[{datetime.datetime.now().isoformat(timespec='seconds')}] {action} | {detail} | {result}\n"
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(line)
    print(line.strip())
