"""Turns transcribed speech into an action. Tries simple, predictable keyword
patterns first (fast, no API needed, easy to audit). If nothing matches and
an ANTHROPIC_API_KEY is set, falls back to Claude for open-ended chat or to
help interpret a fuzzier command.
"""
import re
import config
from modules import system_ops, file_ops
from modules.messaging_email import send_email, read_recent_emails
from modules.messaging_telegram import send_telegram, read_recent_telegram
from modules.messaging_whatsapp import send_whatsapp_now
from modules.messaging_sms import send_sms

_client = None
if config.ANTHROPIC_API_KEY:
    from anthropic import Anthropic
    _client = Anthropic(api_key=config.ANTHROPIC_API_KEY)

SYSTEM_PROMPT = (
    "You are Ultron, an original AI assistant persona (not the Marvel character) "
    "running as a local voice assistant on the user's own Windows PC. You are dry, "
    "precise, a little imperious in tone, but genuinely helpful and safe. Keep replies "
    "short - 1 to 3 sentences - since they're spoken aloud."
)


def _chat_fallback(text: str) -> str:
    if not _client:
        return "I didn't recognize that command, and no Claude API key is configured for open chat. Check the README for supported commands."
    resp = _client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=300,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": text}],
    )
    return "".join(b.text for b in resp.content if b.type == "text").strip()


def handle_command(text: str, confirm_fn=None) -> str:
    t = text.lower().strip()

    # ---- System control ----
    m = re.match(r"open (.+)", t)
    if m:
        app = m.group(1).strip()
        ok = system_ops.open_app(app)
        return f"Opening {app}." if ok else f"Couldn't open {app}."

    m = re.match(r"close (.+)", t)
    if m:
        app = m.group(1).strip()
        proc = app if app.endswith(".exe") else app.split()[0] + ".exe"
        system_ops.close_app(proc)
        return f"Closing {app}."

    if "lock" in t and "pc" in t or t.strip() == "lock":
        system_ops.lock_pc()
        return "Locking the system."

    if "shutdown" in t and "cancel" not in t:
        system_ops.shutdown_pc()
        return "Shutting down in 30 seconds. Say cancel shutdown to stop it."

    if "cancel shutdown" in t:
        system_ops.cancel_shutdown()
        return "Shutdown cancelled."

    m = re.match(r"set volume to (\d+)", t)
    if m:
        pct = int(m.group(1))
        system_ops.set_volume(pct)
        return f"Volume set to {pct} percent."

    m = re.match(r"run command (.+)", t)
    if m:
        return system_ops.run_command(m.group(1).strip(), confirm_fn=confirm_fn)

    # ---- Files ----
    m = re.match(r"(?:find|search for) file (.+)", t)
    if m:
        results = file_ops.search_files(m.group(1).strip())
        if not results:
            return "No matching files found."
        return "Found: " + "; ".join(results[:5])

    m = re.match(r"open file (.+)", t)
    if m:
        matches = file_ops.search_files(m.group(1).strip(), limit=1)
        if not matches:
            return "Couldn't find that file."
        return file_ops.open_file(matches[0])

    m = re.match(r"delete file (.+)", t)
    if m:
        matches = file_ops.search_files(m.group(1).strip(), limit=1)
        if not matches:
            return "Couldn't find that file."
        return file_ops.delete_file(matches[0], confirm_fn=confirm_fn)

    # ---- Messaging ----
    m = re.match(r"email (\S+@\S+) (?:saying |that )?(.+)", t)
    if m:
        to, body = m.group(1), m.group(2)
        return send_email(to, subject="Message from Ultron", body=body, confirm_fn=confirm_fn)

    if t.startswith("read my email") or t.startswith("check my email"):
        return read_recent_emails()

    m = re.match(r"telegram (.+)", t)
    if m:
        return send_telegram(m.group(1).strip(), confirm_fn=confirm_fn)

    if t.startswith("read my telegram") or t.startswith("check telegram"):
        return read_recent_telegram()

    m = re.match(r"whatsapp (.+)", t)
    if m:
        return send_whatsapp_now(m.group(1).strip(), confirm_fn=confirm_fn)

    m = re.match(r"sms (\+?\d[\d\s]{6,}) (.+)", t)
    if m:
        number, body = m.group(1).strip(), m.group(2).strip()
        return send_sms(body, number, confirm_fn=confirm_fn)

    # ---- Nothing matched: fall back to conversation ----
    return _chat_fallback(text)
