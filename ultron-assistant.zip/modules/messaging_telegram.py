"""Telegram via the Bot API. Create a bot with @BotFather to get a token,
then message your bot once so it can message you back (bots can't
message you first until you've started a chat with it)."""
import requests
import config
from modules.logger import log_action


def send_telegram(text: str, chat_id: str = None, confirm_fn=None):
    if not config.TELEGRAM_BOT_TOKEN:
        return "Telegram isn't configured yet - add TELEGRAM_BOT_TOKEN to your .env."
    chat_id = chat_id or config.TELEGRAM_DEFAULT_CHAT_ID
    if not chat_id:
        return "No chat id given, and no TELEGRAM_DEFAULT_CHAT_ID set."
    if confirm_fn and not confirm_fn(f"Send this on Telegram: {text}?"):
        log_action("send_telegram", chat_id, "cancelled by user")
        return "Cancelled."
    try:
        url = f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/sendMessage"
        resp = requests.post(url, data={"chat_id": chat_id, "text": text}, timeout=10)
        resp.raise_for_status()
        log_action("send_telegram", chat_id, "ok")
        return "Telegram message sent."
    except Exception as e:
        log_action("send_telegram", chat_id, f"failed: {e}")
        return f"Couldn't send that Telegram message: {e}"


def read_recent_telegram(limit=5):
    if not config.TELEGRAM_BOT_TOKEN:
        return "Telegram isn't configured yet."
    try:
        url = f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/getUpdates"
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        updates = resp.json().get("result", [])[-limit:]
        lines = []
        for u in updates:
            msg = u.get("message", {})
            sender = msg.get("from", {}).get("first_name", "unknown")
            text = msg.get("text", "")
            if text:
                lines.append(f"{sender}: {text}")
        log_action("read_recent_telegram", str(limit), "ok")
        return "\n".join(lines) if lines else "No recent Telegram messages."
    except Exception as e:
        log_action("read_recent_telegram", str(limit), f"failed: {e}")
        return f"Couldn't read Telegram updates: {e}"
