"""Email via SMTP (send) and IMAP (read recent). Use an app password, never
your real account password."""
import smtplib
import imaplib
import email as email_lib
from email.mime.text import MIMEText
import config
from modules.logger import log_action


def send_email(to_address: str, subject: str, body: str, confirm_fn=None):
    if not config.EMAIL_ADDRESS or not config.EMAIL_APP_PASSWORD:
        return "Email isn't configured yet - add EMAIL_ADDRESS and EMAIL_APP_PASSWORD to your .env."
    if confirm_fn and not confirm_fn(f"Send an email to {to_address} with subject {subject}?"):
        log_action("send_email", to_address, "cancelled by user")
        return "Cancelled."
    try:
        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = config.EMAIL_ADDRESS
        msg["To"] = to_address
        with smtplib.SMTP(config.EMAIL_SMTP_HOST, config.EMAIL_SMTP_PORT) as server:
            server.starttls()
            server.login(config.EMAIL_ADDRESS, config.EMAIL_APP_PASSWORD)
            server.sendmail(config.EMAIL_ADDRESS, [to_address], msg.as_string())
        log_action("send_email", to_address, "ok")
        return "Email sent."
    except Exception as e:
        log_action("send_email", to_address, f"failed: {e}")
        return f"Couldn't send that email: {e}"


def read_recent_emails(count=5):
    if not config.EMAIL_ADDRESS or not config.EMAIL_APP_PASSWORD:
        return "Email isn't configured yet."
    try:
        imap = imaplib.IMAP4_SSL(config.EMAIL_IMAP_HOST)
        imap.login(config.EMAIL_ADDRESS, config.EMAIL_APP_PASSWORD)
        imap.select("INBOX")
        status, data = imap.search(None, "ALL")
        ids = data[0].split()[-count:]
        summaries = []
        for msg_id in reversed(ids):
            status, msg_data = imap.fetch(msg_id, "(RFC822)")
            msg = email_lib.message_from_bytes(msg_data[0][1])
            summaries.append(f"From {msg.get('From')}: {msg.get('Subject')}")
        imap.logout()
        log_action("read_recent_emails", str(count), "ok")
        return "\n".join(summaries) if summaries else "No recent emails found."
    except Exception as e:
        log_action("read_recent_emails", str(count), f"failed: {e}")
        return f"Couldn't read your inbox: {e}"
