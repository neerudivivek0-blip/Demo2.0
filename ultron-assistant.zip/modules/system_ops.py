"""OS-level actions: launching apps, volume/lock/shutdown, and (optionally,
guarded) arbitrary command execution."""
import os
import subprocess
import ctypes
import config
from modules.logger import log_action

# Map spoken names to how Windows actually launches them.
# Add your own entries here for apps you use often.
APP_MAP = {
    "chrome": "chrome",
    "google chrome": "chrome",
    "edge": "msedge",
    "notepad": "notepad",
    "calculator": "calc",
    "explorer": "explorer",
    "file explorer": "explorer",
    "word": "winword",
    "excel": "excel",
    "powerpoint": "powerpnt",
    "spotify": "spotify",
    "vs code": "code",
    "visual studio code": "code",
    "terminal": "wt",
    "settings": "start ms-settings:",
}


def open_app(name: str):
    key = name.lower().strip()
    cmd = APP_MAP.get(key)
    if not cmd:
        # Best-effort fallback: try launching it as typed.
        cmd = key
    try:
        os.system(f"start {cmd}" if not cmd.startswith("start ") else cmd)
        log_action("open_app", key, "ok")
        return True
    except Exception as e:
        log_action("open_app", key, f"failed: {e}")
        return False


def close_app(process_name: str):
    """process_name e.g. 'chrome.exe'"""
    try:
        subprocess.run(["taskkill", "/IM", process_name, "/F"], check=False,
                        capture_output=True)
        log_action("close_app", process_name, "ok")
        return True
    except Exception as e:
        log_action("close_app", process_name, f"failed: {e}")
        return False


def lock_pc():
    ctypes.windll.user32.LockWorkStation()
    log_action("lock_pc", "", "ok")


def shutdown_pc(delay_seconds=30):
    os.system(f"shutdown /s /t {delay_seconds}")
    log_action("shutdown_pc", f"delay={delay_seconds}s", "ok")


def cancel_shutdown():
    os.system("shutdown /a")
    log_action("cancel_shutdown", "", "ok")


def set_volume(percent: int):
    """Requires no extra deps: uses nircmd if present, else falls back to a
    simple keypress-based approach via pyautogui."""
    percent = max(0, min(100, percent))
    try:
        import pyautogui
        # Rough approach: mute, then press volume-up N times out of 50 steps.
        steps = round(percent / 2)
        pyautogui.press("volumemute") if percent == 0 else None
        for _ in range(50):
            pyautogui.press("volumedown")
        for _ in range(steps):
            pyautogui.press("volumeup")
        log_action("set_volume", f"{percent}%", "ok")
        return True
    except Exception as e:
        log_action("set_volume", f"{percent}%", f"failed: {e}")
        return False


def run_command(command: str, confirm_fn=None):
    """Executes an arbitrary shell command. Disabled unless explicitly enabled
    in .env (ENABLE_RUN_COMMAND=true), and always requires confirmation."""
    if not config.ENABLE_RUN_COMMAND:
        log_action("run_command", command, "blocked: disabled in config")
        return "Command execution is disabled in your settings. Enable ENABLE_RUN_COMMAND in .env if you really want this."
    if confirm_fn and not confirm_fn(f"You want to run: {command}. Confirm?"):
        log_action("run_command", command, "cancelled by user")
        return "Cancelled."
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=60)
        output = (result.stdout or "") + (result.stderr or "")
        log_action("run_command", command, "ok")
        return output[:1500] if output else "Command ran with no output."
    except Exception as e:
        log_action("run_command", command, f"failed: {e}")
        return f"Command failed: {e}"
