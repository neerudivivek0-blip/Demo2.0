"""SMS via Twilio. Note: this sends from a Twilio virtual number, NOT your
own personal phone number - there is no public Windows API to script SMS
through your actual carrier line. If you need messages to appear to come
from your real number, look into Twilio number porting or a carrier-specific
business SMS product; that's outside what a local script can do."""
import config
from modules.logger import log_action

try:
    from twilio.rest import Client
except ImportError:
    Client = None


def send_sms(text: str, to_number: str, confirm_fn=None):
    if not (config.TWILIO_ACCOUNT_SID and config.TWILIO_AUTH_TOKEN and config.TWILIO_FROM_NUMBER):
        return "SMS isn't configured yet - add your Twilio credentials to .env."
    if Client is None:
        return "The twilio package isn't installed - run: pip install twilio"
    if confirm_fn and not confirm_fn(f"Send this SMS to {to_number}: {text}?"):
        log_action("send_sms", to_number, "cancelled by user")
        return "Cancelled."
    try:
        client = Client(config.TWILIO_ACCOUNT_SID, config.TWILIO_AUTH_TOKEN)
        client.messages.create(body=text, from_=config.TWILIO_FROM_NUMBER, to=to_number)
        log_action("send_sms", to_number, "ok")
        return "SMS sent."
    except Exception as e:
        log_action("send_sms", to_number, f"failed: {e}")
        return f"Couldn't send that SMS: {e}"
