"""File operations, scoped to the directories listed in FILE_SCOPE_DIRS (.env).
This scoping exists so a misheard voice command can't wander into system
folders - Ultron will refuse to touch anything outside the configured scope.
"""
import os
import shutil
import config
from modules.logger import log_action


def _in_scope(path: str) -> bool:
    if not config.FILE_SCOPE_DIRS:
        return False
    abspath = os.path.abspath(path)
    return any(abspath.lower().startswith(os.path.abspath(d).lower()) for d in config.FILE_SCOPE_DIRS)


def search_files(query: str, limit=15):
    """Case-insensitive filename search within the configured scope."""
    matches = []
    query_l = query.lower()
    for root_dir in config.FILE_SCOPE_DIRS:
        if not os.path.isdir(root_dir):
            continue
        for dirpath, _, filenames in os.walk(root_dir):
            for fn in filenames:
                if query_l in fn.lower():
                    matches.append(os.path.join(dirpath, fn))
                    if len(matches) >= limit:
                        return matches
    return matches


def open_file(path: str):
    if not _in_scope(path):
        log_action("open_file", path, "blocked: out of scope")
        return "That file is outside the folders I'm allowed to touch."
    try:
        os.startfile(path)
        log_action("open_file", path, "ok")
        return f"Opened {os.path.basename(path)}."
    except Exception as e:
        log_action("open_file", path, f"failed: {e}")
        return f"Couldn't open that: {e}"


def move_file(src: str, dest_dir: str):
    if not (_in_scope(src) and _in_scope(dest_dir)):
        log_action("move_file", f"{src} -> {dest_dir}", "blocked: out of scope")
        return "That move touches a folder outside my allowed scope."
    try:
        shutil.move(src, dest_dir)
        log_action("move_file", f"{src} -> {dest_dir}", "ok")
        return "Moved."
    except Exception as e:
        log_action("move_file", f"{src} -> {dest_dir}", f"failed: {e}")
        return f"Couldn't move that: {e}"


def rename_file(src: str, new_name: str):
    if not _in_scope(src):
        log_action("rename_file", src, "blocked: out of scope")
        return "That file is outside my allowed scope."
    try:
        new_path = os.path.join(os.path.dirname(src), new_name)
        os.rename(src, new_path)
        log_action("rename_file", f"{src} -> {new_name}", "ok")
        return "Renamed."
    except Exception as e:
        log_action("rename_file", src, f"failed: {e}")
        return f"Couldn't rename that: {e}"


def delete_file(path: str, confirm_fn=None):
    """Sends to a 'recycle' folder inside the scope root rather than a hard
    delete, so mistakes are recoverable. confirm_fn is called for a spoken
    yes/no gate."""
    if not _in_scope(path):
        log_action("delete_file", path, "blocked: out of scope")
        return "That file is outside my allowed scope - refusing."
    if confirm_fn and not confirm_fn(f"Delete {os.path.basename(path)}? This cannot be easily undone once confirmed."):
        log_action("delete_file", path, "cancelled by user")
        return "Cancelled."
    try:
        scope_root = next(d for d in config.FILE_SCOPE_DIRS if os.path.abspath(path).lower().startswith(os.path.abspath(d).lower()))
        recycle_dir = os.path.join(scope_root, "_ultron_deleted")
        os.makedirs(recycle_dir, exist_ok=True)
        shutil.move(path, os.path.join(recycle_dir, os.path.basename(path)))
        log_action("delete_file", path, "moved to _ultron_deleted")
        return "Done - moved to the _ultron_deleted folder in case you need it back."
    except Exception as e:
        log_action("delete_file", path, f"failed: {e}")
        return f"Couldn't delete that: {e}"
