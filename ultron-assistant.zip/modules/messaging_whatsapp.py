"""WhatsApp via pywhatkit, which drives WhatsApp Web in your default browser.
Your browser must already be logged into web.whatsapp.com (scan the QR code
once manually) before this will work. This is unofficial automation, not
WhatsApp's real API, so it's a little slower and less reliable than Telegram
or email - expect it to pop your browser open and wait ~15-20 seconds."""
import pywhatkit
import config
from modules.logger import log_action


def send_whatsapp_now(text: str, phone: str = None, confirm_fn=None):
    phone = phone or config.WHATSAPP_DEFAULT_PHONE
    if not phone:
        return "No phone number given, and no WHATSAPP_DEFAULT_PHONE set."
    if confirm_fn and not confirm_fn(f"Send this on WhatsApp to {phone}: {text}?"):
        log_action("send_whatsapp", phone, "cancelled by user")
        return "Cancelled."
    try:
        pywhatkit.sendwhatmsg_instantly(phone, text, wait_time=18, tab_close=True)
        log_action("send_whatsapp", phone, "ok")
        return "WhatsApp message sent."
    except Exception as e:
        log_action("send_whatsapp", phone, f"failed: {e}")
        return f"Couldn't send that WhatsApp message: {e}"
