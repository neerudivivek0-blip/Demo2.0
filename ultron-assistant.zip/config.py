"""Central config loader. Reads .env and exposes typed settings."""
import os
from dotenv import load_dotenv

load_dotenv()

def _bool(name, default=False):
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")

WAKE_WORD = os.getenv("WAKE_WORD", "ultron").lower()
VOICE_RATE = int(os.getenv("VOICE_RATE", "170"))

CONFIRM_DESTRUCTIVE_ACTIONS = _bool("CONFIRM_DESTRUCTIVE_ACTIONS", True)
ENABLE_RUN_COMMAND = _bool("ENABLE_RUN_COMMAND", False)

FILE_SCOPE_DIRS = [
    p.strip() for p in os.getenv("FILE_SCOPE_DIRS", "").split(",") if p.strip()
]

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()

EMAIL_ADDRESS = os.getenv("EMAIL_ADDRESS", "")
EMAIL_APP_PASSWORD = os.getenv("EMAIL_APP_PASSWORD", "")
EMAIL_IMAP_HOST = os.getenv("EMAIL_IMAP_HOST", "imap.gmail.com")
EMAIL_SMTP_HOST = os.getenv("EMAIL_SMTP_HOST", "smtp.gmail.com")
EMAIL_SMTP_PORT = int(os.getenv("EMAIL_SMTP_PORT", "587"))

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_DEFAULT_CHAT_ID = os.getenv("TELEGRAM_DEFAULT_CHAT_ID", "")

WHATSAPP_DEFAULT_PHONE = os.getenv("WHATSAPP_DEFAULT_PHONE", "")

TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")
TWILIO_FROM_NUMBER = os.getenv("TWILIO_FROM_NUMBER", "")
