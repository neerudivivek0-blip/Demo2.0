"""Ultron - local voice assistant entry point.

Run: python main.py

Say the wake word (default "ultron"), wait for the prompt tone/print, then
say your command. Ctrl+C to quit.
"""
import config
from modules.voice import speak, listen, confirm
from modules.intents import handle_command


def main():
    speak("Systems online. I'm listening for the wake word.")
    print(f"(Wake word is '{config.WAKE_WORD}'. Press Ctrl+C to quit.)")

    while True:
        try:
            heard = listen(timeout=None, phrase_time_limit=4) if False else listen(timeout=8, phrase_time_limit=4)
            if not heard:
                continue

            if config.WAKE_WORD not in heard:
                continue

            # Strip the wake word in case the command was said in the same breath,
            # e.g. "ultron open chrome"
            remainder = heard.split(config.WAKE_WORD, 1)[1].strip()

            if not remainder:
                speak("Yes?")
                remainder = listen(timeout=8, phrase_time_limit=8)
                if not remainder:
                    speak("I didn't catch that.")
                    continue

            confirm_fn = confirm if config.CONFIRM_DESTRUCTIVE_ACTIONS else (lambda prompt: True)
            response = handle_command(remainder, confirm_fn=confirm_fn)
            speak(response)

        except KeyboardInterrupt:
            speak("Shutting down. Goodbye.")
            break
        except Exception as e:
            print(f"Unexpected error: {e}")
            speak("Something went wrong on that one.")


if __name__ == "__main__":
    main()
