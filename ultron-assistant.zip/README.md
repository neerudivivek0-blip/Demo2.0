# Ultron — Local Voice Assistant (Windows)

A voice-controlled assistant that runs **on your machine**, not in a browser.
It can open/close apps, control volume, lock/shut down the PC, search/open/
move/rename/delete files in folders you choose, and send messages over
email, Telegram, WhatsApp, and SMS (via Twilio).

## ⚠️ Read this before running it

- This script can **run arbitrary shell commands** if you turn that on, and
  can **send messages and delete files** on your behalf. Treat it like you'd
  treat any tool with real access to your accounts and disk.
- **Do not run it as Administrator.** Run it under your normal user account.
- **Keep `ENABLE_RUN_COMMAND=false`** unless you specifically need arbitrary
  command execution. It's off by default for a reason.
- **Keep `CONFIRM_DESTRUCTIVE_ACTIONS=true`.** This makes Ultron say what
  it's about to do and wait for a spoken/typed "yes" before deleting a file,
  sending a message, or running a command. Turning it off means a
  misheard word could trigger something irreversible.
- File operations are restricted to the folders listed in `FILE_SCOPE_DIRS`
  in your `.env`. Keep this list narrow (Desktop/Documents/Downloads is
  usually enough) — never point it at `C:\Windows` or your whole `C:\`.
- Deleted files are moved to an `_ultron_deleted` folder inside the scope,
  not permanently erased, as a safety net.
- Every action is logged to `ultron_action_log.txt` in this folder — check
  it if anything seems off.
- **Never commit or share your `.env` file.** It holds real credentials.

## 1. Install Python dependencies

Requires Python 3.10+ on Windows.

```
pip install -r requirements.txt
```

`pyaudio` sometimes fails to install via pip on Windows. If it does:
```
pip install pipwin
pipwin install pyaudio
```

## 2. Configure

```
copy .env.example .env
```
Then open `.env` and fill in only the sections you actually plan to use —
everything is optional and features degrade gracefully if left blank.

- **File scope**: set `FILE_SCOPE_DIRS` to real folders on your PC.
- **Email**: use an **App Password** (Gmail: Google Account → Security →
  App Passwords), not your real password.
- **Telegram**: message [@BotFather](https://t.me/BotFather) on Telegram,
  run `/newbot`, copy the token. Then send your new bot any message once
  (bots can't message you first), and use
  `https://api.telegram.org/bot<token>/getUpdates` in a browser to find your
  numeric chat ID.
- **WhatsApp**: no token needed, but your **default browser must already be
  logged into web.whatsapp.com** (scan the QR code once manually first).
- **SMS**: create a free [Twilio](https://www.twilio.com/) account for a
  trial number, and put the SID/token/number in `.env`. Note this sends
  from a *Twilio number*, not your real personal number — there's no public
  Windows API to script SMS through your actual carrier line.
- **Smarter chat/parsing (optional)**: add your own `ANTHROPIC_API_KEY` if
  you want Ultron to hold open-ended conversation for anything that isn't a
  recognized command.

## 3. Run it

```
python main.py
```

Say **"Ultron"** to wake it, then your command — either in one breath
("Ultron, open Chrome") or after it prompts "Yes?".

## Example commands

| Say | Does |
|---|---|
| "open chrome" | Launches Chrome |
| "close chrome" | Force-closes Chrome |
| "lock" | Locks the PC |
| "shutdown" | Shuts down in 30s (say "cancel shutdown" to stop) |
| "set volume to 40" | Sets system volume |
| "find file budget" | Searches your scoped folders |
| "open file budget" | Opens the first match |
| "delete file budget" | Confirms, then moves it to `_ultron_deleted` |
| "email jane@example.com saying I'll be late" | Sends an email |
| "read my email" | Reads back your 5 most recent subject lines |
| "telegram running 10 minutes late" | Sends via your Telegram bot |
| "whatsapp on my way" | Sends via WhatsApp Web |
| "sms +911234567890 call me" | Sends via Twilio |
| "run command dir" | Only works if `ENABLE_RUN_COMMAND=true`, and always confirms first |
| anything else | Falls back to open conversation (needs `ANTHROPIC_API_KEY`) |

## Extending it

- Add more apps to `APP_MAP` in `modules/system_ops.py`.
- Add new command patterns in `modules/intents.py` — each is just a regex
  and a function call.
- Swap `speak()` in `modules/voice.py` for a call to a custom TTS API (like
  a cloned voice service) if you want a specific voice instead of the
  built-in Windows one — replace `pyttsx3` with an HTTP call that returns
  audio and play it with a library like `playsound` or `simpleaudio`.
